/* ======================================================================================= */
/* ======================================================================================= */
// Class: CS-1C
// Creator: Joshua Yang
// Contact: joshuayang0324@gmail.com
// Professor: Kath
// Date: 2/28/19
/* ======================================================================================= */
// Rules/Algorithm: Write a program that uses a random number generator to generate
// a three digit integer that allows the user to perform the following operation.
// 1. Sum the digits
// 2. Triple the number
// 3. Reverse the digitis
// b. Use an enum, typedef, and string variable
// c. Store 10 random numbers in an array
// d. Sort the array
// e. Write the array to an external file
// f. Call a function to read the external file
// g. Print the array in a function
// Use the command script to capture your interaction compiling and running 
// the program, including all operations, as shown below:
/* ======================================================================================= */
// Work: 
// CS1C Spring 2019 TTH HW-1 50pts Due: Th 1/24/2019
// cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ script hw01.scr
// Script started, file is hw01.scr
// cs1c@cs1c-VirtualBox ~/cs1c/hw01 $ date
// ... 
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ Is -1
// ... 
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ make all
// ...
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ Is -1
// ...
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ ./hw01
// ...//print out parts a, d & g above
// cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ exit
// Script done, file is hw01.scr
// Cs1c@cs1c-VirtualBox ~/cs1c/hw/01 $ make tar
// ...
// Submit the tar package file hw01.tar by Thursday January 24, 2019.
/* ======================================================================================= */
/* ======================================================================================= */
// Code:
#include <iostream>
#include <string>
#include <iomanip>      // std::setw
using namespace std;

struct Item
{
        string name;
        int quantity;
        float cost;
};
const int MAX_SIZE = 50;
class ManageInventory
{
    public:
        ManageInventory() :
                count { 0 }, p_pInventoryItems { new Item*[size] }
        {
        }
        ManageInventory(int size) :
                size { size }, count { 0 }, p_pInventoryItems { new Item*[size] }
        {
        }
        ~ManageInventory();
        void addItem(string name, int quantity, float cost);
        void print();
    private:
        int size { MAX_SIZE };
        int count;
        Item ** p_pInventoryItems;
};

int main(int agrc, char* agrv[])
{

    ManageInventory inventory;
    inventory.addItem("Nike basketball shoes", 22, 145.99);
    inventory.addItem("Under Armour T-shirt", 33, 29.99);
    inventory.addItem("Brooks running shoes", 11, 111.44);
    inventory.addItem("Asics running shoes", 20, 165.88);
    inventory.addItem("Nike shorts", 77, 45.77);

    inventory.print();
    return 0;
}

/**
 * 1. Write the definition for addItem. Use the new operator to
 * dynamically create instances of type Item. Store pointers to
 * inventory items in the inventoryItems array
 */
void ManageInventory::addItem(string name, int quatity, float cost)
{
    if (count < size)
    {
        Item *x = new Item;
        x->name = name;
        x->quantity = quatity;
        x->cost = cost;
        p_pInventoryItems[count++] = x;
    }
    else
        cout << "Inventory items are full" << endl;
}

/**
 * 2. Write the ManageInventory class destructor definition. Use
 * the delete operator to dynamically destroy all Item objs
 * stored in the inventoryItems array.
 */
ManageInventory::~ManageInventory()
{
    for (int i = 0; i < count; i++)
    {
        delete p_pInventoryItems[i];
    }
    delete[] p_pInventoryItems;
}

void ManageInventory::print()
{
    cout << "|" << std::left << std::setw(25) << "Name" << "|" << std::setw(10) << "Cost" << "|" << std::setw(10) << "Quantity" << "|" << endl;
    cout << "-------------------------------------------------" << endl;
    for (int i = 0; i < count; i++)
    {
        cout << "|" << std::left << std::setw(25) << p_pInventoryItems[i]->name << "|" << std::setw(10) << p_pInventoryItems[i]->cost << "|" << std::setw(10)
                << p_pInventoryItems[i]->quantity << "|" << endl;
    }
}
